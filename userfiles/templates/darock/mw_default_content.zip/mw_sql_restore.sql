/* Microweber database export exported on: Monday 24th of November 2014 01:13:12 PM */ 
/* MW_TABLE_PREFIX: test4_ */ 




CREATE TABLE IF NOT EXISTS `/* MW_PREFIX_PLACEHOLDER */cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text,
  `is_active` char(1) DEFAULT 'y',
  `rel_id` int(11) DEFAULT NULL,
  `rel` varchar(350) DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `price` float DEFAULT NULL,
  `currency` varchar(33) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `qty` int(11) DEFAULT NULL,
  `other_info` text,
  `order_completed` char(1) DEFAULT 'n',
  `order_id` varchar(255) DEFAULT NULL,
  `skip_promo_code` char(1) DEFAULT 'n',
  `created_by` int(11) DEFAULT NULL,
  `custom_fields_data` text,
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(255)),
  KEY `rel_id` (`rel_id`),
  KEY `session_id` (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("3","Climb With My Shoes","y","8","content","2014-11-13 14:34:27","2014-11-13 14:29:13","233","","vkqr8r15ck3st91orgrpptafi1","3","","n","","n","1","W10="); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("4","Get My Camera","y","9","content","2014-11-13 14:33:25","2014-11-13 14:30:14","3580","","vkqr8r15ck3st91orgrpptafi1","3","","n","","n","1","W10="); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("5","Climb With My Shoes","y","8","content","2014-11-13 17:09:13","2014-11-13 17:09:13","399","","cg78jik1sqj1e80m9hmq9cg3a7","1","","n","","n","","eyJDaG9vc2UgYSBjb2xvciI6IlB1cnBsZSJ9"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("6","Get My Camera","y","9","content","2014-11-14 10:27:05","2014-11-14 09:49:21","3580","","n6qhjtldkuphqd80a4iq4ekk51","1","","n","","n","1","W10="); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("7","Get My Camera","y","9","content","2014-11-14 11:15:42","2014-11-14 11:13:53","3580","","2siahh6ht565t9qi2jjvqd15l4","4","","n","","n","","eyJDaG9vc2UgQ29sb3IiOiJCbGFjayIsIkRyb3Bkb3duIjoiT3B0aW9uIDEifQ=="); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("8","Get My Camera","y","9","content","2014-11-14 11:24:09","2014-11-14 11:24:09","3580","","u6bcngc5clonlh98ksad0fepm5","1","","y","1","n","","eyJDaG9vc2UgQ29sb3IiOiJCbGFjayIsIkRyb3Bkb3duIjoiT3B0aW9uIDIiLCJTaW5nbGUgQ2hvaWNlIjoiU2luZ2xlIDEifQ=="); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("9","Get My Camera","y","9","content","2014-11-14 12:04:56","2014-11-14 12:04:56","3580","","3vbj7hli95joh00mo4bf5laeu4","1","","y","2","n","1","W10="); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("10","Get My Camera","y","9","content","2014-11-14 12:06:48","2014-11-14 12:06:48","3580","","3vbj7hli95joh00mo4bf5laeu4","1","","y","3","n","1","W10="); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("11","Climb With My Shoes","y","8","content","2014-11-14 12:06:51","2014-11-14 12:06:51","233","","3vbj7hli95joh00mo4bf5laeu4","1","","y","3","n","1","W10="); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("12","Get My Camera","y","9","content","2014-11-14 12:59:57","2014-11-14 12:59:57","3580","","oo4h217l6km1n6l9bufiu1qmf4","1","","n","","n","1","W10="); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("13","Care My Bag","y","6","content","2014-11-14 13:41:20","2014-11-14 13:17:30","140","","3vbj7hli95joh00mo4bf5laeu4","8","","n","","n","1","W10="); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("14","Climb With My Shoes","y","8","content","2014-11-14 13:24:34","2014-11-14 13:24:34","233","","3vbj7hli95joh00mo4bf5laeu4","1","","n","","n","1","W10="); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("15","Get My Camera","y","9","content","2014-11-14 14:07:45","2014-11-14 13:56:17","3580","","5nndniden2425di7m1dkp9o760","1","","n","","n","","W10="); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("16","Care My Bag","y","6","content","2014-11-14 14:25:21","2014-11-14 14:25:14","140","","5nndniden2425di7m1dkp9o760","5","","n","","n","1","W10="); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("17","Climb With My Shoes","y","8","content","2014-11-17 11:58:15","2014-11-17 11:58:15","233","","j4fph32rc7sqp5b77jctqn0m82","1","","n","","n","","eyJDaG9vc2UgYSBjb2xvciI6IlB1cnBsZSJ9"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart VALUES("18","Get My Camera","y","9","content","2014-11-24 13:12:35","2014-11-24 13:12:35","3580","","et2q32r2qv8ga53aai7vfpgb71","1","","n","","n","1","W10="); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS `/* MW_PREFIX_PLACEHOLDER */cart_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `country` varchar(255) DEFAULT NULL,
  `promo_code` text,
  `amount` float DEFAULT NULL,
  `transaction_id` text,
  `shipping_service` text,
  `shipping` float DEFAULT NULL,
  `currency` varchar(33) DEFAULT NULL,
  `currency_code` varchar(33) DEFAULT NULL,
  `first_name` text,
  `last_name` text,
  `email` text,
  `city` text,
  `state` text,
  `zip` text,
  `address` text,
  `address2` text,
  `phone` text,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `session_id` varchar(255) DEFAULT NULL,
  `order_completed` char(1) DEFAULT 'n',
  `is_paid` char(1) DEFAULT 'n',
  `url` text,
  `user_ip` varchar(255) DEFAULT NULL,
  `items_count` int(11) DEFAULT NULL,
  `custom_fields_data` text,
  `payment_gw` text,
  `payment_verify_token` text,
  `payment_amount` float DEFAULT NULL,
  `payment_currency` varchar(255) DEFAULT NULL,
  `payment_status` varchar(255) DEFAULT NULL,
  `payment_email` text,
  `payment_receiver_email` text,
  `payment_name` text,
  `payment_country` text,
  `payment_address` text,
  `payment_city` text,
  `payment_state` text,
  `payment_zip` text,
  `payer_id` text,
  `payer_status` text,
  `payment_type` text,
  `order_status` varchar(255) DEFAULT 'pending',
  `payment_shipping` float DEFAULT NULL,
  `is_active` char(1) DEFAULT 'y',
  `rel_id` int(11) DEFAULT NULL,
  `rel` varchar(350) DEFAULT NULL,
  `price` float DEFAULT NULL,
  `other_info` text,
  `order_id` varchar(255) DEFAULT NULL,
  `skip_promo_code` char(1) DEFAULT 'n',
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_orders VALUES("1","2014-11-14 11:25:29","2014-11-14 11:25:29","Bulgaria","","3580","","shop/shipping/gateways/country","0","USD","","Boris","Sokolov","me@mailinator.com","Sofia","Sofia","1172","sv. pimen zografski 14","","4951424","","","u6bcngc5clonlh98ksad0fepm5","y","n","{SITE_URL}checkout","192.168.0.106","1","","shop/payments/gateways/pay_on_delivery","4bb0372ce0f16c8da762ced199e3e98a","","","","","","","","","","","","","","","pending","","y","","","","","","n"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_orders VALUES("2","2014-11-14 12:05:18","2014-11-14 12:05:18","Algeria","","3580","","shop/shipping/gateways/country","0","USD","","as","as","1","","","","","","asd","1","1","3vbj7hli95joh00mo4bf5laeu4","y","n","{SITE_URL}checkout","192.168.0.107","1","","shop/payments/gateways/pay_on_delivery","d29e8bcb60708ca60b3595a2779fcc0c","","","","","","","","","","","","","","","pending","","y","","","","","","n"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_orders VALUES("3","2014-11-14 12:07:49","2014-11-14 12:07:49","Bulgaria","","3813","","shop/shipping/gateways/country","0","USD","","Alexander","Raykov","alex@microweber.com","Sofia","Sofia","1172","Pimen Zografski 14 str. ap 22","","+359123456789","1","1","3vbj7hli95joh00mo4bf5laeu4","y","n","{SITE_URL}checkout","192.168.0.107","2","","shop/payments/gateways/pay_on_delivery","32dd24fcc20eab06b8242af8285365d4","","","","","","","","","","","","","","","pending","","y","","","","","","n"); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS `/* MW_PREFIX_PLACEHOLDER */cart_shipping` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `is_active` char(1) DEFAULT 'y',
  `shipping_cost` float DEFAULT NULL,
  `shipping_cost_max` float DEFAULT NULL,
  `shipping_cost_above` float DEFAULT NULL,
  `shipping_country` text,
  `position` int(11) DEFAULT NULL,
  `shipping_type` text,
  `shipping_price_per_size` float DEFAULT NULL,
  `shipping_price_per_weight` float DEFAULT NULL,
  `shipping_price_per_item` float DEFAULT NULL,
  `shipping_price_custom` float DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */cart_shipping VALUES("1","2014-11-14 09:56:38","2014-11-14 09:56:38","y","0","0","0","Worldwide","","fixed","0","0","0",""); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS `/* MW_PREFIX_PLACEHOLDER */categories` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `data_type` text,
  `title` longtext,
  `parent_id` int(11) DEFAULT NULL,
  `description` text,
  `content` text,
  `content_type` text,
  `rel` text,
  `rel_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `is_deleted` char(1) DEFAULT 'n',
  `users_can_create_subcategories` char(1) DEFAULT 'n',
  `users_can_create_content` char(1) DEFAULT 'n',
  `users_can_create_content_allowed_usergroups` text,
  `categories_content_type` text,
  `categories_silo_keywords` text,
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(55)),
  KEY `rel_id` (`rel_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("21","2014-11-13 14:57:12","2014-02-27 15:52:07","1","1","category","Stone Art","0","","","","content","4","0","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("22","2014-11-13 14:57:25","2014-02-27 15:52:28","1","1","category","Wild Animals","0","","","","content","4","0","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("27","2014-03-24 12:28:50","2014-02-28 08:56:35","1","1","category","Products","0","","","","content","13","0","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("35","2014-11-13 14:58:16","2014-11-13 14:58:16","1","1","category","Rock&#039;s","0","","","","content","4","0","n","n","n","","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories VALUES("36","2014-11-14 09:04:27","2014-11-14 09:04:27","1","1","category","Digital Cameras","27","","","","content","0","0","n","n","n","","",""); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS `/* MW_PREFIX_PLACEHOLDER */categories_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `parent_id` int(11) DEFAULT NULL,
  `rel` text,
  `rel_id` int(11) DEFAULT NULL,
  `content_type` text,
  `data_type` text,
  PRIMARY KEY (`id`),
  KEY `rel_id` (`rel_id`),
  KEY `parent_id` (`parent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=514 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("507","22","content","16","","category_item"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("508","21","content","17","","category_item"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("509","35","content","12","","category_item"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("510","27","content","9","","category_item"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("511","36","content","9","","category_item"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("512","27","content","8","","category_item"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */categories_items VALUES("513","27","content","6","","category_item"); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS `/* MW_PREFIX_PLACEHOLDER */comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel` text,
  `rel_id` text,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `comment_name` text,
  `comment_body` longtext,
  `comment_email` text,
  `comment_website` text,
  `is_moderated` char(1) DEFAULT 'n',
  `from_url` text,
  `comment_subject` text,
  `is_new` char(1) DEFAULT 'y',
  `for_newsletter` char(1) DEFAULT 'n',
  `session_id` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */comments VALUES("1","content","11","2014-02-27 10:37:54","2014-02-27 10:37:30","1","1","","some comment","","","y","{SITE_URL}megaaaa-post","","n","n","scq0cahpp1c1hnidhn15qhcrb7"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */comments VALUES("2","content","16","2014-03-27 12:35:48","2014-03-27 12:35:48","1","1","","Aweosme","","","y","{SITE_URL}art-of-nuts-mokassarart","","y","n","s3svoo27pqr094mi2rhp6cmk32"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */comments VALUES("3","content","16","2014-03-27 13:33:57","2014-03-27 13:33:57","1","1","","test comment","","","y","{SITE_URL}art-of-nuts-mokassarart?editmode=n","","y","n","s3svoo27pqr094mi2rhp6cmk32"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */comments VALUES("4","content","17","2014-03-27 15:46:51","2014-03-27 15:46:51","1","1","","Comment 1","","","y","{SITE_URL}100-premium-infographics-from-ingimage-only-18","","y","n","s3svoo27pqr094mi2rhp6cmk32"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */comments VALUES("5","content","29","2014-03-27 17:05:47","2014-03-27 17:05:35","1","1","","hello","","","y","{SITE_URL}test-post","","n","n","icm8mbhl7orpb4c42ag2m0d592"); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS `/* MW_PREFIX_PLACEHOLDER */content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `expires_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `content_type` text,
  `url` longtext,
  `content_filename` text,
  `title` longtext,
  `parent` int(11) DEFAULT NULL,
  `description` text,
  `content_meta_title` text,
  `content_meta_keywords` text,
  `position` int(11) DEFAULT '1',
  `content` longtext,
  `content_body` longtext,
  `is_active` char(1) DEFAULT 'y',
  `is_home` char(1) DEFAULT 'n',
  `is_pinged` char(1) DEFAULT 'n',
  `is_shop` char(1) DEFAULT 'n',
  `is_deleted` char(1) DEFAULT 'n',
  `draft_of` int(11) DEFAULT NULL,
  `require_login` char(1) DEFAULT 'n',
  `status` text,
  `subtype` text,
  `subtype_value` text,
  `custom_type` text,
  `custom_type_value` text,
  `original_link` text,
  `layout_file` text,
  `layout_name` text,
  `layout_style` text,
  `active_site_template` text,
  `session_id` varchar(255) DEFAULT NULL,
  `posted_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `url` (`url`(255)),
  KEY `title` (`title`(255))
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("4","2014-11-24 12:49:27","2014-02-21 11:09:43","0000-00-00 00:00:00","1","1","page","blog","","Blog","0","","","","6","","","y","n","n","n","n","0","n","","dynamic","","","","","layouts\\blog.php","","","default","k1bavvdde8ubeddj7ntlu1dki2","2014-11-24 12:49:27"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("6","2014-11-24 12:57:19","2014-02-21 11:18:24","0000-00-00 00:00:00","1","1","post","care-my-bag","","Care My Bag","13","","","","8","\n			<div class=\"mw-row\" id=\"row_1395661252975\" style=\"height: auto;\">\n				<div class=\"mw-col selected\" style=\"height: auto; width: 65%;\" id=\"mw-column-1395661252966\" data-also-rezise-item=\"mw-column-1395661252967\">\n					<div class=\"mw-col-container\">\n						<module class=\"module module  \" data-mw-title=\"Picture Gallery\" id=\"-bird-lamp1167824773\" rel=\"content\" template=\"product_gallery\" data-type=\"pictures\" data-parent-module=\"shop/cart_add\" data-parent-module-id=\"-bird-lamp1706281220\"></module>\n</div>\n				</div>\n				<div class=\"mw-col\" style=\"height: auto; width: 35%;\" id=\"mw-column-1395661252967\">\n					<div class=\"mw-col-container\">\n						<div class=\"product-description element\">\n							<p class=\"element\" id=\"row_1395661253029\">This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative &amp; <strong style=\"font-weight: 600\" class=\"\">Make Web</strong>.</p>\n							<module class=\"module module\" data-mw-title=\"Add to cart\" id=\"-bird-lamp1706281220\" rel=\"post\" data-type=\"shop/cart_add\" data-parent-module=\"shop/cart_add\" data-parent-module-id=\"-bird-lamp1706281220\"></module>\n</div>\n						</div>\n					</div>\n				</div>\n			\n		","","y","n","n","n","n","0","n","","product","","","","","","","","","avrhf6nvg79jpsuqobluvdt4i2","2014-02-21 11:18:24"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("8","2014-11-24 12:57:06","2014-02-21 12:44:13","0000-00-00 00:00:00","1","1","post","climb-with-my-shoesfemale-jeans","","Climb With My Shoes","13","","","","9","\n			<div id=\"row_1395668451731\" style=\"height: auto;\" class=\"mw-row\">\n				<div data-also-rezise-item=\"mw-column-1395668451708\" id=\"mw-column-1395668451707\" class=\"mw-col \" style=\"width: 65%; height: auto;\">\n					<div class=\"mw-col-container\">\n						<module class=\"module module  \" data-mw-title=\"Picture Gallery\" id=\"-female-jeans1167824773\" rel=\"content\" template=\"product_gallery\" data-type=\"pictures\" data-parent-module=\"shop/cart_add\" data-parent-module-id=\"-female-jeans1706281220\"></module>\n</div>\n				</div>\n				<div id=\"mw-column-1395668451708\" class=\"mw-col\" style=\"width: 35%; height: auto;\">\n					<div class=\"mw-col-container\">\n						<div class=\"product-description element\" id=\"row_1415883413099\">\n							<p id=\"row_1395668451730\" class=\"element\">This text is set by default and it is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative &amp; <strong class=\"\" style=\"font-weight: 600\">Make Web</strong>.</p>\n							<module class=\"module module\" data-mw-title=\"Add to cart\" id=\"-female-jeans1706281220\" rel=\"post\" data-type=\"shop/cart_add\" data-parent-module=\"shop/cart_add\" data-parent-module-id=\"-female-jeans1706281220\"></module>\n</div>\n						</div>\n					</div>\n				</div>\n			\n		","","y","n","n","n","n","0","n","","product","","","","","","","","","s3svoo27pqr094mi2rhp6cmk32","2014-02-21 12:44:13"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("9","2014-11-24 12:56:33","2014-02-21 12:46:40","0000-00-00 00:00:00","1","1","post","get-my-camera","","Get My Camera","13","","","","10","\n					<div class=\"mw-row\" id=\"row_1395660084006\" style=\"height: auto;\">\n						<div class=\"mw-col selected \" style=\"height: auto; width: 65%;\" id=\"mw-column-1395660083994\" data-also-rezise-item=\"mw-column-1395660083995\">\n							<div class=\"mw-col-container\">\n								<module class=\"module module\" data-mw-title=\"Picture Gallery\" style=\"cursor: pointer;\" id=\"-editor_tools1167824773\" rel=\"content\" template=\"product_gallery\" data-type=\"pictures\" data-parent-module=\"shop/cart_add\" data-parent-module-id=\"-man-jeans1706281220\"></module>\n</div>\n						</div>\n						<div class=\"mw-col\" style=\"height: auto; width: 35%;\" id=\"mw-column-1395660083995\">\n							<div class=\"mw-col-container\">\n								<div class=\"product-description element\" id=\"row_1395660084127\">\n									<p id=\"row_1395660084152\" class=\"element\">This text is set by default and it is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative &amp; <strong class=\"\" style=\"font-weight: 600\">Make Web</strong>.</p>\n									<module class=\"module module module  \" data-mw-title=\"Add to cart\" id=\"-editor_tools1706281220\" rel=\"post\" data-type=\"shop/cart_add\" data-parent-module=\"shop/cart_add\" data-parent-module-id=\"-man-jeans1706281220\"></module>\n</div>\n</div>\n</div>\n							</div>\n						\n					\n				","","y","n","n","n","n","0","n","","product","","","","","","","","","mpd0b0e164mctt08rqum0m6285","2014-02-21 12:46:40"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("12","2014-11-24 12:47:38","2014-02-27 10:48:06","0000-00-00 00:00:00","1","1","post","pure-nature","","Pure Nature","4","","","","15","\n                    <module class=\"module module module\" data-mw-title=\"Picture Gallery\" style=\"cursor: pointer;\" id=\"-editor_tools-844116804\" data-type=\"pictures\" data-template=\"bootstrap_carousel\" rel=\"content\" data-parent-module=\"comments\" data-parent-module-id=\"-editor_tools-1561113661\"></module><div id=\"row_1393510392831\" class=\"element\" style=\"width:95%\">\n						<p id=\"row_1393510392828\" class=\"element\" align=\"justify\">This text is set by default and is suitable for edit in real time. By \ndefault the drag and drop core feature will allow you to position it \nanywhere on the site. Get creative, Make Web.</p>\n					</div>\n				","","y","n","n","n","n","0","n","","post","","","","","","","","","uabsultfkqd41iafblfcq258c1","2014-02-27 10:48:06"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("13","2014-11-24 12:57:19","2014-02-28 08:48:56","0000-00-00 00:00:00","1","1","page","shop","","Shop","0","","","","4","","","y","n","n","y","n","0","n","","dynamic","","","","","layouts__shop.php","","","default","mpd0b0e164mctt08rqum0m6285","2014-11-24 12:57:19"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("14","2014-11-13 11:39:33","2014-03-17 11:20:53","0000-00-00 00:00:00","1","1","page","home","","Home","0","","","","5","","","y","y","n","n","n","0","n","","static","","","","","index.php","","","default","vl88c3hubmlhj5829b3pooh8i1","2014-03-17 14:54:00"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("16","2014-11-24 12:46:59","2014-03-17 12:14:07","0000-00-00 00:00:00","1","1","post","wild-animals","","Wild Animals","4","","","","14","\n\n                    \n\n					<div class=\"element\" style=\"width:95%\" id=\"row_1395660523321\">\n						<p align=\"justify\" class=\"element\" id=\"row_1395660523322\">This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative, Make Web.</p>\n<module class=\"clear module module  \" data-mw-title=\"Picture Gallery\" data-type=\"pictures\" id=\"pictures-20140324112912\" content-id=\"16\" data-parent-module=\"comments\" data-parent-module-id=\"-editor_tools764533908\"></module><p align=\"justify\" class=\"element\" id=\"row_1395660523323\"><br class=\"\"></p>\n					</div>\n				","","y","n","n","n","n","0","n","","post","","","","","","","","","uabsultfkqd41iafblfcq258c1","2014-03-17 12:14:07"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("17","2014-11-24 12:47:16","2014-03-17 12:35:20","0000-00-00 00:00:00","1","1","post","the-rock","","The Rock","4","","","","16","\n\n                    \n\n					<div id=\"row_1395672540648\" class=\"element\" style=\"width:95%\">\n						<p id=\"row_1395672540649\" class=\"element\" align=\"justify\">This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative, Make Web.</p>\n<p id=\"row_1395672540650\" class=\"element\" align=\"justify\">It was popularised in the 1960s with \nthe release of Letraset sheets containing Lorem Ipsum passages, and more\n recently with desktop publishing software like Aldus PageMaker \nincluding versions of Lorem Ipsum.</p>\n					</div>\n<module class=\"clear element module module\" data-mw-title=\"Picture Gallery\" data-type=\"pictures\" id=\"row_1395672540651\" content-id=\"17\"></module><div class=\" element text\" data-mw-title=\"Text\" data-type=\"text\" id=\"text-20140324144941\"><p id=\"row_1395672542174\" class=\"element lipsum\"><strong class=\"\">Lorem Ipsum</strong> is simply dummy text of the printing and \ntypesetting industry. Lorem Ipsum has been the industry\'s standard dummy\n text ever since the 1500s, when an unknown printer took a galley of \ntype and scrambled it to make a type specimen book. It has survived not \nonly five centuries, but also the leap into electronic typesetting, \nremaining essentially unchanged. It was popularised in the 1960s with \nthe release of Letraset sheets containing Lorem Ipsum passages, and more\n recently with desktop publishing software like Aldus PageMaker \nincluding versions of Lorem Ipsum.</p></div>\n","","y","n","n","n","n","0","n","","post","","","","","","","","","avrhf6nvg79jpsuqobluvdt4i2","2014-03-17 12:35:20"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("20","2014-11-24 12:07:27","2014-03-24 10:48:08","0000-00-00 00:00:00","1","1","page","gallery","","Gallery","0","","","","7","","","y","n","n","n","n","0","n","","static","","","","","layouts\\gallery.php","","","default","uabsultfkqd41iafblfcq258c1","2014-03-24 10:48:08"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("25","2014-03-28 08:54:23","2014-03-26 17:03:37","0000-00-00 00:00:00","1","1","page","contacts","","Contact us","0","","","","2","","","y","n","n","n","n","0","n","","static","","","","","contacts.php","","","default","avrhf6nvg79jpsuqobluvdt4i2","2014-03-26 17:03:37"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("29","2014-11-13 12:26:45","2014-11-13 12:25:27","","1","1","page","about","","About","0","","","","3","","","y","n","n","n","n","","n","","static","","","","","text_page.php","","","default","vkqr8r15ck3st91orgrpptafi1","2014-11-13 12:25:27"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("30","2014-11-24 12:49:27","2014-11-14 12:40:23","","1","1","post","art","","Art","4","","","","13","\n            <module class=\"module module module\" data-mw-title=\"Picture Gallery\" id=\"-editor_tools-1462002108\" data-type=\"pictures\" data-template=\"slider\" rel=\"content\" data-parent-module=\"shop/cart\" data-parent-module-id=\"-editor_tools-1201179899\"></module><div class=\"edit element\" field=\"content_body\" rel=\"content\">\n              <div class=\"element\">\n                <p align=\"justify\" class=\" element\">This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative, Make Web.</p>\n              </div>\n            </div>\n          ","","y","n","n","n","n","","n","","post","","","","","inherit","","","","u6bcngc5clonlh98ksad0fepm5","2014-11-14 12:40:23"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("31","2014-11-24 12:32:36","2014-11-14 12:45:26","","1","1","post","design","","Design","4","","","","11","\n            <module class=\"module module module  \" data-mw-title=\"Picture Gallery\" id=\"-editor_tools1533426608\" data-type=\"pictures\" data-template=\"simple\" rel=\"content\" data-parent-module=\"shop/cart\" data-parent-module-id=\"-editor_tools-1201179899\"></module><div class=\"edit element\" field=\"content_body\" rel=\"content\">\n              <div class=\"element\">\n                <p align=\"justify\" class=\" element\" id=\"row_1415969043120\">This text is set by default and is suitable for edit in real time. By default the drag and drop core feature will allow you to position it anywhere on the site. Get creative, Make Web.</p>\n              </div>\n            </div>\n          ","","y","n","n","n","n","","n","","post","","","","","inherit","","","","u6bcngc5clonlh98ksad0fepm5","2014-11-14 12:45:26"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content VALUES("32","2014-11-24 12:33:18","2014-11-14 12:48:15","","1","1","post","cool-stuff","","Cool Stuff","4","","","","12","","","y","n","n","n","n","","n","","post","","","","","inherit","","","","u6bcngc5clonlh98ksad0fepm5","2014-11-14 12:48:15"); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS `/* MW_PREFIX_PLACEHOLDER */content_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `content_id` varchar(11) DEFAULT NULL,
  `field_name` longtext,
  `field_value` longtext,
  `session_id` varchar(50) DEFAULT NULL,
  `rel` text,
  `rel_id` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("1","2014-11-24 12:56:33","2014-11-13 12:54:02","1","1","9","qty","nolimit","oujar0k793lhk6e4rfjv5uqlj0","content","9"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("2","2014-11-24 12:56:33","2014-11-13 12:54:02","1","1","9","sku","","oujar0k793lhk6e4rfjv5uqlj0","content","9"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("3","2014-11-24 12:56:33","2014-11-13 12:54:02","1","1","9","shipping_weight","","oujar0k793lhk6e4rfjv5uqlj0","content","9"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("4","2014-11-24 12:56:33","2014-11-13 12:54:02","1","1","9","shipping_width","","oujar0k793lhk6e4rfjv5uqlj0","content","9"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("5","2014-11-24 12:56:33","2014-11-13 12:54:02","1","1","9","shipping_height","","oujar0k793lhk6e4rfjv5uqlj0","content","9"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("6","2014-11-24 12:56:33","2014-11-13 12:54:02","1","1","9","shipping_depth","","oujar0k793lhk6e4rfjv5uqlj0","content","9"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("7","2014-11-24 12:56:33","2014-11-13 12:54:02","1","1","9","additional_shipping_cost","","oujar0k793lhk6e4rfjv5uqlj0","content","9"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("8","2014-11-24 12:57:06","2014-11-13 13:00:48","1","1","8","qty","nolimit","fv3rejhclkgopptd4ji601pmk0","content","8"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("9","2014-11-24 12:57:06","2014-11-13 13:00:48","1","1","8","sku","","fv3rejhclkgopptd4ji601pmk0","content","8"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("10","2014-11-24 12:57:06","2014-11-13 13:00:48","1","1","8","shipping_weight","","fv3rejhclkgopptd4ji601pmk0","content","8"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("11","2014-11-24 12:57:06","2014-11-13 13:00:48","1","1","8","shipping_width","","fv3rejhclkgopptd4ji601pmk0","content","8"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("12","2014-11-24 12:57:06","2014-11-13 13:00:48","1","1","8","shipping_height","","fv3rejhclkgopptd4ji601pmk0","content","8"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("13","2014-11-24 12:57:06","2014-11-13 13:00:48","1","1","8","shipping_depth","","fv3rejhclkgopptd4ji601pmk0","content","8"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("14","2014-11-24 12:57:06","2014-11-13 13:00:48","1","1","8","additional_shipping_cost","","fv3rejhclkgopptd4ji601pmk0","content","8"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("15","2014-11-24 12:57:19","2014-11-13 14:01:45","1","1","6","qty","nolimit","fv3rejhclkgopptd4ji601pmk0","content","6"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("16","2014-11-24 12:57:20","2014-11-13 14:01:45","1","1","6","sku","","fv3rejhclkgopptd4ji601pmk0","content","6"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("17","2014-11-24 12:57:20","2014-11-13 14:01:45","1","1","6","shipping_weight","","fv3rejhclkgopptd4ji601pmk0","content","6"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("18","2014-11-24 12:57:20","2014-11-13 14:01:45","1","1","6","shipping_width","","fv3rejhclkgopptd4ji601pmk0","content","6"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("19","2014-11-24 12:57:20","2014-11-13 14:01:45","1","1","6","shipping_height","","fv3rejhclkgopptd4ji601pmk0","content","6"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("20","2014-11-24 12:57:20","2014-11-13 14:01:45","1","1","6","shipping_depth","","fv3rejhclkgopptd4ji601pmk0","content","6"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_data VALUES("21","2014-11-24 12:57:20","2014-11-13 14:01:45","1","1","6","additional_shipping_cost","","fv3rejhclkgopptd4ji601pmk0","content","6"); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS `/* MW_PREFIX_PLACEHOLDER */content_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `rel` text,
  `rel_id` text,
  `field` longtext,
  `value` longtext,
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(55)),
  KEY `rel_id` (`rel_id`(255))
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields VALUES("1","2014-11-13 14:51:46","2014-11-13 14:51:46","1","1","content","17","post-social-bar","\n            <div class=\"blog-socials-bar element\" style=\"width: 320px;margin: auto;\">\n              <div class=\"mw-ui-row-nodrop element\">\n                <div class=\"mw-ui-col\" style=\"width: 60px;\">\n                  <div class=\"mw-ui-col-container\">\n                    <module class=\" module  \" id=\"-100-premium-infographics-from-ingimage-only-18-189188252\" data-mw-title=\"Facebook Like\" show-faces=\"false\" layout=\"box_count\" data-type=\"facebook_like\"></module>\n                  </div>\n                </div>\n                <div class=\"mw-ui-col\">\n                  <div class=\"mw-ui-col-container\" style=\"padding-top: 25px;\">\n                    <iframe id=\"twitter-widget-0\" scrolling=\"no\" frameborder=\"0\" allowtransparency=\"true\" src=\"http://platform.twitter.com/widgets/tweet_button.d58098f8a7f0ff5a206e7f15442a6b30.en.html#_=1415890283759&amp;count=horizontal&amp;id=twitter-widget-0&amp;lang=en&amp;original_referer=http%3A%2F%2Ftest4.com%2FMicroweber%2F100-premium-infographics-from-ingimage-only-18&amp;size=l&amp;text=Simple%20blog%20post&amp;url=http%3A%2F%2Ftest4.com%2FMicroweber%2F100-premium-infographics-from-ingimage-only-18\" class=\"twitter-share-button twitter-tweet-button twitter-share-button twitter-count-horizontal\" title=\"Twitter Tweet Button\" data-twttr-rendered=\"true\" style=\"width: 136px; height: 28px;\"></iframe>\n                    \n</div>\n                </div>\n\n                <div class=\"mw-ui-col\">\n                  <div class=\"mw-ui-col-container\" style=\"padding-top: 25px;\">\n                    <a data-pin-href=\"http://www.pinterest.com/pin/create/button/\" data-pin-log=\"button_pinit_bookmarklet\" class=\"PIN_1415890283783_pin_it_button_28 PIN_1415890283783_pin_it_button_en_28_gray PIN_1415890283783_pin_it_button_inline_28 PIN_1415890283783_pin_it_none_28\" data-pin-config=\"none\"><span class=\"PIN_1415890283783_hidden\" id=\"PIN_1415890283783_pin_count_0\"><i></i></span></a>\n                    \n</div>\n                </div>\n\n\n\n\n\n              </div>\n            </div>\n          "); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields VALUES("2","2014-11-24 12:16:35","2014-11-24 12:16:35","1","1","content","17","title","The Rock"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields VALUES("3","2014-11-24 12:18:26","2014-11-24 12:18:26","1","1","content","30","post-social-bar","\n            <div class=\"blog-socials-bar element\" style=\"width: 320px;\">\n              <div class=\"mw-ui-row-nodrop element\">\n                <div class=\"mw-ui-col\" style=\"width: 60px;\">\n                  <div class=\"mw-ui-col-container\">\n                    <module class=\" module  \" id=\"-art-189188252\" data-mw-title=\"Facebook Like\" show-faces=\"false\" layout=\"box_count\" data-type=\"facebook_like\"></module>\n                  </div>\n                </div>\n                <div class=\"mw-ui-col\">\n                  <div class=\"mw-ui-col-container\" style=\"padding-top: 25px;\">\n                    <iframe id=\"twitter-widget-0\" scrolling=\"no\" frameborder=\"0\" allowtransparency=\"true\" src=\"http://platform.twitter.com/widgets/tweet_button.3c2cf6c04ef79ac64fb26744da5cc1b0.en.html#_=1416831455183&amp;count=horizontal&amp;id=twitter-widget-0&amp;lang=en&amp;original_referer=http%3A%2F%2Ftest4.com%2FMicroweber%2Fart&amp;size=l&amp;text=Art&amp;url=http%3A%2F%2Ftest4.com%2FMicroweber%2Fart\" class=\"twitter-share-button twitter-tweet-button twitter-share-button twitter-count-horizontal\" title=\"Twitter Tweet Button\" data-twttr-rendered=\"true\" style=\"width: 136px; height: 28px;\"></iframe>\n                    \n</div>\n                </div>\n\n                <div class=\"mw-ui-col\">\n                  <div class=\"mw-ui-col-container\" style=\"padding-top: 25px;\">\n                    <a data-pin-href=\"http://www.pinterest.com/pin/create/button/\" data-pin-log=\"button_pinit_bookmarklet\" class=\"PIN_1416831455354_pin_it_button_28 PIN_1416831455354_pin_it_button_en_28_gray PIN_1416831455354_pin_it_button_inline_28 PIN_1416831455354_pin_it_none_28\" data-pin-config=\"none\"><span class=\"PIN_1416831455354_hidden\" id=\"PIN_1416831455354_pin_count_0\"><i></i></span></a>\n                    \n</div>\n                </div>\n              </div>\n            </div>\n          "); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields VALUES("4","2014-11-24 12:32:36","2014-11-24 12:32:36","1","1","content","31","post-social-bar","\n            <div class=\"blog-socials-bar element\" style=\"width: 320px;\">\n              <div class=\"mw-ui-row-nodrop element\">\n                <div class=\"mw-ui-col\" style=\"width: 60px;\">\n                  <div class=\"mw-ui-col-container\">\n                    <module class=\" module  \" id=\"-design-189188252\" data-mw-title=\"Facebook Like\" show-faces=\"false\" layout=\"box_count\" data-type=\"facebook_like\"></module>\n                  </div>\n                </div>\n                <div class=\"mw-ui-col\">\n                  <div class=\"mw-ui-col-container\" style=\"padding-top: 25px;\">\n                    <iframe id=\"twitter-widget-0\" scrolling=\"no\" frameborder=\"0\" allowtransparency=\"true\" src=\"http://platform.twitter.com/widgets/tweet_button.3c2cf6c04ef79ac64fb26744da5cc1b0.en.html#_=1416832285916&amp;count=horizontal&amp;id=twitter-widget-0&amp;lang=en&amp;original_referer=http%3A%2F%2Ftest4.com%2FMicroweber%2Fdesign&amp;size=l&amp;text=Design&amp;url=http%3A%2F%2Ftest4.com%2FMicroweber%2Fdesign\" class=\"twitter-share-button twitter-tweet-button twitter-share-button twitter-count-horizontal\" title=\"Twitter Tweet Button\" data-twttr-rendered=\"true\" style=\"width: 136px; height: 28px;\"></iframe>\n                    \n</div>\n                </div>\n\n                <div class=\"mw-ui-col\">\n                  <div class=\"mw-ui-col-container\" style=\"padding-top: 25px;\">\n                    <a data-pin-href=\"http://www.pinterest.com/pin/create/button/\" data-pin-log=\"button_pinit_bookmarklet\" class=\"PIN_1416832285467_pin_it_button_28 PIN_1416832285467_pin_it_button_en_28_gray PIN_1416832285467_pin_it_button_inline_28 PIN_1416832285467_pin_it_none_28\" data-pin-config=\"none\"><span class=\"PIN_1416832285467_hidden\" id=\"PIN_1416832285467_pin_count_0\"><i></i></span></a>\n                    \n</div>\n                </div>\n              </div>\n            </div>\n          "); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */content_fields VALUES("5","2014-11-24 12:33:13","2014-11-24 12:33:13","1","1","content","32","post-social-bar","\n            <div class=\"blog-socials-bar element\" style=\"width: 320px;\">\n              <div class=\"mw-ui-row-nodrop element\">\n                <div class=\"mw-ui-col\" style=\"width: 60px;\">\n                  <div class=\"mw-ui-col-container\">\n                    <module class=\" module  \" id=\"-cool-stuff-189188252\" data-mw-title=\"Facebook Like\" show-faces=\"false\" layout=\"box_count\" data-type=\"facebook_like\"></module>\n                  </div>\n                </div>\n                <div class=\"mw-ui-col\">\n                  <div class=\"mw-ui-col-container\" style=\"padding-top: 25px;\">\n                    <iframe id=\"twitter-widget-0\" scrolling=\"no\" frameborder=\"0\" allowtransparency=\"true\" src=\"http://platform.twitter.com/widgets/tweet_button.3c2cf6c04ef79ac64fb26744da5cc1b0.en.html#_=1416832387785&amp;count=horizontal&amp;id=twitter-widget-0&amp;lang=en&amp;original_referer=http%3A%2F%2Ftest4.com%2FMicroweber%2Fcool-stuff&amp;size=l&amp;text=Cool%20Stuff&amp;url=http%3A%2F%2Ftest4.com%2FMicroweber%2Fcool-stuff\" class=\"twitter-share-button twitter-tweet-button twitter-share-button twitter-count-horizontal\" title=\"Twitter Tweet Button\" data-twttr-rendered=\"true\" style=\"width: 136px; height: 28px;\"></iframe>\n                    \n</div>\n                </div>\n\n                <div class=\"mw-ui-col\">\n                  <div class=\"mw-ui-col-container\" style=\"padding-top: 25px;\">\n                    <a data-pin-href=\"http://www.pinterest.com/pin/create/button/\" data-pin-log=\"button_pinit_bookmarklet\" class=\"PIN_1416832387375_pin_it_button_28 PIN_1416832387375_pin_it_button_en_28_gray PIN_1416832387375_pin_it_button_inline_28 PIN_1416832387375_pin_it_none_28\" data-pin-config=\"none\"><span class=\"PIN_1416832387375_hidden\" id=\"PIN_1416832387375_pin_count_0\"><i></i></span></a>\n                    \n</div>\n                </div>\n              </div>\n            </div>\n          "); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS `/* MW_PREFIX_PLACEHOLDER */custom_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `rel` text,
  `rel_id` text,
  `position` int(11) DEFAULT NULL,
  `type` text,
  `name` text,
  `value` text,
  `num_value` float DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `session_id` varchar(50) DEFAULT NULL,
  `custom_field_name` text,
  `custom_field_name_plain` longtext,
  `custom_field_value` text,
  `custom_field_type` text,
  `custom_field_values` longtext,
  `custom_field_values_plain` longtext,
  `field_for` text,
  `custom_field_field_for` text,
  `custom_field_help_text` text,
  `options` text,
  `custom_field_is_active` char(1) DEFAULT 'y',
  `custom_field_required` char(1) DEFAULT 'n',
  `copy_of_field` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(55)),
  KEY `rel_id` (`rel_id`(55)),
  KEY `custom_field_type` (`custom_field_type`(55))
) ENGINE=InnoDB AUTO_INCREMENT=144 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("2","content","6","0","price","Price","140","140","2014-11-13 14:01:45","2014-02-21 11:17:57","1","1","945qrn5u3lr9mrcg2r0ddsrjr7","Price","price","140","price","","140","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("4","content","8","0","","","","","2014-02-21 12:44:12","2014-02-21 11:46:36","1","1","v1f98ctvbi616uel5fmkbtf0s2","Price","","399","price","","399","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("5","content","9","0","price","Price","3580","3580","2014-11-13 13:19:01","2014-02-21 12:44:16","1","1","v1f98ctvbi616uel5fmkbtf0s2","Price","price","3580","price","","3580","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("6","module","skin_num_1d8fe257cc08506d3ee52e1c8568e57a9","0","","","","","2014-03-17 10:08:03","2014-03-17 10:08:03","1","1","e7ih3vmpbcoitt7c4s54v9i6u1","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("7","module","skin_num_1d8fe257cc08506d3ee52e1c8568e57a9","1","","","","","2014-03-17 10:08:03","2014-03-17 10:08:03","1","1","e7ih3vmpbcoitt7c4s54v9i6u1","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("8","module","skin_num_1d8fe257cc08506d3ee52e1c8568e57a9","2","","","","","2014-03-17 10:08:03","2014-03-17 10:08:03","1","1","e7ih3vmpbcoitt7c4s54v9i6u1","Text","","","text","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("11","module","shipping-info--checkout557478767","0","","","","","2014-03-18 10:50:11","2014-03-18 10:50:11","1","1","1jsp8fm9p0te6tjm0dsmhd1ii0","Address","","","address","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("12","module","shipping-info--module432994985","0","","","","","2014-03-18 10:50:17","2014-03-18 10:50:17","1","1","1jsp8fm9p0te6tjm0dsmhd1ii0","Address","","","address","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("13","module","contact-form-20140319103911","0","","","","","2014-03-19 10:39:12","2014-03-19 10:39:12","1","1","alk6rv91oaj0vv9em5m08ol260","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("14","module","contact-form-20140319103911","1","","","","","2014-03-19 10:39:12","2014-03-19 10:39:12","1","1","alk6rv91oaj0vv9em5m08ol260","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("15","module","contact-form-20140319103911","2","","","","","2014-03-19 10:39:12","2014-03-19 10:39:12","1","1","alk6rv91oaj0vv9em5m08ol260","Text","","","text","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("17","module","contact-form-20140324165237","0","","","","","2014-03-24 16:52:37","2014-03-24 16:52:37","1","1","uabsultfkqd41iafblfcq258c1","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("18","module","contact-form-20140324165237","1","","","","","2014-03-24 16:52:37","2014-03-24 16:52:37","1","1","uabsultfkqd41iafblfcq258c1","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("19","module","contact-form-20140324165237","2","","","","","2014-03-24 16:52:37","2014-03-24 16:52:37","1","1","uabsultfkqd41iafblfcq258c1","Text","","","text","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("20","module","contact-form-20140324165250","0","","","","","2014-03-24 16:52:50","2014-03-24 16:52:50","1","1","uabsultfkqd41iafblfcq258c1","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("21","module","contact-form-20140324165250","1","","","","","2014-03-24 16:52:50","2014-03-24 16:52:50","1","1","uabsultfkqd41iafblfcq258c1","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("22","module","contact-form-20140324165250","2","","","","","2014-03-24 16:52:50","2014-03-24 16:52:50","1","1","uabsultfkqd41iafblfcq258c1","Text","","","text","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("23","module","contact-form-20140324165457","0","","","","","2014-03-24 16:54:57","2014-03-24 16:54:57","1","1","uabsultfkqd41iafblfcq258c1","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("24","module","contact-form-20140324165457","1","","","","","2014-03-24 16:54:57","2014-03-24 16:54:57","1","1","uabsultfkqd41iafblfcq258c1","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("25","module","contact-form-20140324165457","2","","","","","2014-03-24 16:54:57","2014-03-24 16:54:57","1","1","uabsultfkqd41iafblfcq258c1","Text","","","text","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("31","content","8","0","","","","","2014-03-25 10:50:21","2014-03-25 10:49:40","1","1","s3svoo27pqr094mi2rhp6cmk32","Choose a color","","Array","dropdown","YTozOntpOjA7czo2OiJQdXJwbGUiO2k6MTtzOjU6IkJyb3duIjtpOjI7czo0OiJCbHVlIjt9","Purple, Brown, Blue","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("73","module","contact-form","0","","","","","2014-03-26 17:03:25","2014-03-26 17:03:25","1","1","s3svoo27pqr094mi2rhp6cmk32","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("74","module","contact-form","1","","","","","2014-03-26 17:03:25","2014-03-26 17:03:25","1","1","s3svoo27pqr094mi2rhp6cmk32","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("76","module","contact-form-20140327090204","0","","","","","2014-03-27 09:02:04","2014-03-27 09:02:04","1","1","s3svoo27pqr094mi2rhp6cmk32","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("77","module","contact-form-20140327090204","1","","","","","2014-03-27 09:02:04","2014-03-27 09:02:04","1","1","s3svoo27pqr094mi2rhp6cmk32","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("78","module","contact-form-20140327090204","2","","","","","2014-03-27 09:02:04","2014-03-27 09:02:04","1","1","s3svoo27pqr094mi2rhp6cmk32","Text","","","text","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("80","module","contact-form","2","message","Message","","0","2014-11-20 13:07:06","2014-03-27 11:03:08","1","1","s3svoo27pqr094mi2rhp6cmk32","Message","message","","message","","","","","","eyJhc190ZXh0X2FyZWEiOlsiMSJdfQ==","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("81","module","contact-form-20140327110408","0","","","","","2014-03-27 11:04:08","2014-03-27 11:04:08","1","1","s3svoo27pqr094mi2rhp6cmk32","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("82","module","contact-form-20140327110408","1","","","","","2014-03-27 11:04:08","2014-03-27 11:04:08","1","1","s3svoo27pqr094mi2rhp6cmk32","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("83","module","contact-form-20140327110408","2","","","","","2014-03-27 11:04:08","2014-03-27 11:04:08","1","1","s3svoo27pqr094mi2rhp6cmk32","Message","","","message","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("84","module","contact-form-20140327110652","0","","","","","2014-03-27 11:06:52","2014-03-27 11:06:52","1","1","s3svoo27pqr094mi2rhp6cmk32","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("85","module","contact-form-20140327110652","1","","","","","2014-03-27 11:06:52","2014-03-27 11:06:52","1","1","s3svoo27pqr094mi2rhp6cmk32","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("86","module","contact-form-20140327110652","2","","","","","2014-03-27 11:06:52","2014-03-27 11:06:52","1","1","s3svoo27pqr094mi2rhp6cmk32","Message","","","message","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("87","module","contact-form-20140327110717","0","","","","","2014-03-27 11:07:17","2014-03-27 11:07:17","1","1","s3svoo27pqr094mi2rhp6cmk32","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("88","module","contact-form-20140327110717","1","","","","","2014-03-27 11:07:17","2014-03-27 11:07:17","1","1","s3svoo27pqr094mi2rhp6cmk32","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("89","module","contact-form-20140327110717","2","","","","","2014-03-27 11:07:17","2014-03-27 11:07:17","1","1","s3svoo27pqr094mi2rhp6cmk32","Message","","","message","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("90","module","contact-form-20140327110821","0","","","","","2014-03-27 11:08:21","2014-03-27 11:08:21","1","1","s3svoo27pqr094mi2rhp6cmk32","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("91","module","contact-form-20140327110821","1","","","","","2014-03-27 11:08:21","2014-03-27 11:08:21","1","1","s3svoo27pqr094mi2rhp6cmk32","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("92","module","contact-form-20140327110821","2","","","","","2014-03-27 11:08:21","2014-03-27 11:08:21","1","1","s3svoo27pqr094mi2rhp6cmk32","Message","","","message","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("93","module","contact-form-20140327110907","0","","","","","2014-03-27 11:09:07","2014-03-27 11:09:07","1","1","s3svoo27pqr094mi2rhp6cmk32","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("94","module","contact-form-20140327110907","1","","","","","2014-03-27 11:09:07","2014-03-27 11:09:07","1","1","s3svoo27pqr094mi2rhp6cmk32","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("95","module","contact-form-20140327110907","2","","","","","2014-03-27 11:09:07","2014-03-27 11:09:07","1","1","s3svoo27pqr094mi2rhp6cmk32","Message","","","message","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("96","forms_data","1","1","","","","","2014-03-26 17:03:25","2014-03-26 17:03:25","1","1","s3svoo27pqr094mi2rhp6cmk32","Name","","jygfhgjhg","name","","","","","","","y","n","73"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("97","forms_data","1","2","","","","","2014-03-26 17:03:25","2014-03-26 17:03:25","1","1","s3svoo27pqr094mi2rhp6cmk32","Email","","hg@hjg","email","","","","","","","y","n","74"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("98","forms_data","1","3","","","","","2014-03-27 11:03:08","2014-03-27 11:03:08","1","1","s3svoo27pqr094mi2rhp6cmk32","Message","","jkh","message","","","","","","","y","n","80"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("99","module","contact-form-20140327114853","0","","","","","2014-03-27 11:48:53","2014-03-27 11:48:53","1","1","s3svoo27pqr094mi2rhp6cmk32","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("100","module","contact-form-20140327114853","1","","","","","2014-03-27 11:48:53","2014-03-27 11:48:53","1","1","s3svoo27pqr094mi2rhp6cmk32","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("101","module","contact-form-20140327114853","2","","","","","2014-03-27 11:48:53","2014-03-27 11:48:53","1","1","s3svoo27pqr094mi2rhp6cmk32","Message","","","message","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("102","module","contact-form-20140327125802","0","","","","","2014-03-27 12:58:02","2014-03-27 12:58:02","1","1","s3svoo27pqr094mi2rhp6cmk32","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("103","module","contact-form-20140327125802","1","","","","","2014-03-27 12:58:02","2014-03-27 12:58:02","1","1","s3svoo27pqr094mi2rhp6cmk32","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("104","module","contact-form-20140327125802","2","","","","","2014-03-27 12:58:02","2014-03-27 12:58:02","1","1","s3svoo27pqr094mi2rhp6cmk32","Message","","","message","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("107","module","contact-form-20140327141953","0","","","","","2014-03-27 14:19:53","2014-03-27 14:19:53","1","1","s3svoo27pqr094mi2rhp6cmk32","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("108","module","contact-form-20140327141953","1","","","","","2014-03-27 14:19:53","2014-03-27 14:19:53","1","1","s3svoo27pqr094mi2rhp6cmk32","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("109","module","contact-form-20140327141953","2","","","","","2014-03-27 14:19:53","2014-03-27 14:19:53","1","1","s3svoo27pqr094mi2rhp6cmk32","Message","","","message","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("110","module","contact-form-20140327142001","0","","","","","2014-03-27 14:20:01","2014-03-27 14:20:01","1","1","s3svoo27pqr094mi2rhp6cmk32","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("111","module","contact-form-20140327142001","1","","","","","2014-03-27 14:20:01","2014-03-27 14:20:01","1","1","s3svoo27pqr094mi2rhp6cmk32","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("112","module","contact-form-20140327142001","2","","","","","2014-03-27 14:20:01","2014-03-27 14:20:01","1","1","s3svoo27pqr094mi2rhp6cmk32","Message","","","message","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("113","module","contact-form-20140327142014","0","","","","","2014-03-27 14:20:14","2014-03-27 14:20:14","1","1","s3svoo27pqr094mi2rhp6cmk32","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("114","module","contact-form-20140327142014","1","","","","","2014-03-27 14:20:14","2014-03-27 14:20:14","1","1","s3svoo27pqr094mi2rhp6cmk32","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("115","module","contact-form-20140327142014","2","","","","","2014-03-27 14:20:14","2014-03-27 14:20:14","1","1","s3svoo27pqr094mi2rhp6cmk32","Message","","","message","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("116","module","contact-form-20140327142128","0","","","","","2014-03-27 14:21:28","2014-03-27 14:21:28","1","1","s3svoo27pqr094mi2rhp6cmk32","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("117","module","contact-form-20140327142128","1","","","","","2014-03-27 14:21:28","2014-03-27 14:21:28","1","1","s3svoo27pqr094mi2rhp6cmk32","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("118","module","contact-form-20140327142128","2","","","","","2014-03-27 14:21:28","2014-03-27 14:21:28","1","1","s3svoo27pqr094mi2rhp6cmk32","Message","","","message","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("132","module","contact-form-20140328104104","0","","","","","2014-03-28 10:41:04","2014-03-28 10:41:04","1","1","k1bavvdde8ubeddj7ntlu1dki2","Name","","","name","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("133","module","contact-form-20140328104104","1","","","","","2014-03-28 10:41:04","2014-03-28 10:41:04","1","1","k1bavvdde8ubeddj7ntlu1dki2","Email","","","email","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("134","module","contact-form-20140328104104","2","","","","","2014-03-28 10:41:04","2014-03-28 10:41:04","1","1","k1bavvdde8ubeddj7ntlu1dki2","Message","","","message","","","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("135","content","6","0","","","","","2014-03-28 13:41:29","2014-03-28 13:40:55","1","1","m6si87bl2o224mncs0b5cj6ee5","Choose Color","","Array","dropdown","YTozOntpOjA7czo1OiJCbGFjayI7aToxO3M6MzoiUmVkIjtpOjI7czo1OiJXaGl0ZSI7fQ==","Black, Red, White","","","","","y","n","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("137","content","9","0","","","","","2014-03-28 13:47:54","2014-03-28 13:40:55","1","1","m6si87bl2o224mncs0b5cj6ee5","Choose Color","","Array","dropdown","YTozOntpOjA7czo1OiJCbGFjayI7aToxO3M6MzoiUmVkIjtpOjI7czo1OiJXaGl0ZSI7fQ==","Black, Red, White","","","","","y","n","135"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("138","content","9","12","","","","","2014-03-27 16:08:50","2014-03-27 16:01:54","1","1","m6si87bl2o224mncs0b5cj6ee5","Single Choice","","Array","radio","YTozOntpOjA7czo4OiJTaW5nbGUgMSI7aToxO3M6ODoiU2luZ2xlIDIiO2k6MjtzOjg6IlNpbmdsZSAzIjt9","Single 1, Single 2, Single 3","","","","","y","n","127"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("139","content","9","13","","","","","2014-03-27 16:09:54","2014-03-27 16:01:58","1","1","m6si87bl2o224mncs0b5cj6ee5","Dropdown","","Array","dropdown","YToyOntpOjA7czo4OiJPcHRpb24gMSI7aToxO3M6ODoiT3B0aW9uIDIiO30=","Option 1, Option 2","","","","","y","n","128"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("140","content","8","","price","White lampshade","233","233","2014-11-13 13:00:44","2014-11-13 12:58:29","1","1","fv3rejhclkgopptd4ji601pmk0","White lampshade","white lampshade","233","price","YToxOntpOjA7czozOiIyMzMiO30=","233","","","","","y","n",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("141","content","8","","price","Wood Lapm","150","150","2014-11-13 12:59:20","2014-11-13 12:59:05","1","1","fv3rejhclkgopptd4ji601pmk0","Wood Lapm","wood lapm","150","price","YToxOntpOjA7czozOiIxNTAiO30=","150","","","","","y","n",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("142","module","shipping-info-432994985","0","address","Address","","0","2014-11-14 09:57:02","2014-11-14 09:57:02","1","1","cg78jik1sqj1e80m9hmq9cg3a7","Address","address","","address","","","","","","","y","n",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */custom_fields VALUES("143","module","shipping-info-557478767","0","address","Address","","0","2014-11-14 10:11:57","2014-11-14 10:11:57","1","1","n6qhjtldkuphqd80a4iq4ekk51","Address","address","","address","","","","","","","y","n",""); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS `/* MW_PREFIX_PLACEHOLDER */forms_data` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `rel` text,
  `rel_id` text,
  `list_id` int(11) DEFAULT '0',
  `form_values` text,
  `module_name` text,
  `url` text,
  `user_ip` text,
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(55)),
  KEY `rel_id` (`rel_id`(255)),
  KEY `list_id` (`list_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */forms_data VALUES("1","2014-11-14 09:57:46","1","module","contact-form","0","","contact_form","","192.168.0.107"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */forms_data VALUES("2","2014-11-24 12:51:45","","module","contact-form","0","","contact_form","","192.168.0.107"); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS `/* MW_PREFIX_PLACEHOLDER */media` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `session_id` varchar(50) DEFAULT NULL,
  `rel` text,
  `rel_id` varchar(255) DEFAULT '0',
  `media_type` text,
  `position` int(11) DEFAULT NULL,
  `title` longtext,
  `description` text,
  `embed_code` text,
  `filename` text,
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(55)),
  KEY `rel_id` (`rel_id`),
  KEY `media_type` (`media_type`(55))
) ENGINE=InnoDB AUTO_INCREMENT=279 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("17","2014-03-17 10:12:42","2014-03-17 10:12:42","1","1","e7ih3vmpbcoitt7c4s54v9i6u1","modules","--1891520885","picture","9999999","","","","{SITE_URL}userfiles/templates/liteness/img/sample/content/modules/7288.Dell_20Latitude_2010_20Windows_208_20tablet_20_small__11.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("134","2014-03-24 16:55:26","2014-03-24 16:55:26","1","1","uabsultfkqd41iafblfcq258c1","modules","pictures-20140324165515","picture","9999999","","","","{SITE_URL}userfiles/templates/liteness/img/sample/content/modules/201403241655262011_Mercedes_Benz_CLS550_20.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("135","2014-03-24 16:55:26","2014-03-24 16:55:26","1","1","uabsultfkqd41iafblfcq258c1","modules","pictures-20140324165515","picture","9999999","","","","{SITE_URL}userfiles/templates/liteness/img/sample/content/modules/201403241655267288.Dell_20Latitude_2010_20Windows_208_20tablet_20_small__11.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("136","2014-03-24 16:55:26","2014-03-24 16:55:26","1","1","uabsultfkqd41iafblfcq258c1","modules","pictures-20140324165515","picture","9999999","","","","{SITE_URL}userfiles/templates/liteness/img/sample/content/modules/2014032416552622133_46486.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("137","2014-03-24 16:55:27","2014-03-24 16:55:27","1","1","uabsultfkqd41iafblfcq258c1","modules","pictures-20140324165515","picture","9999999","","","","{SITE_URL}userfiles/templates/liteness/img/sample/content/modules/20140324165527120404144321_10.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("164","2014-11-13 11:46:15","2014-11-13 11:46:15","1","1","oujar0k793lhk6e4rfjv5uqlj0","content","20","picture","0","","","","{SITE_URL}userfiles/media/content/9997862744_c050066a2a_h.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("171","2014-11-13 12:15:20","2014-11-13 12:15:20","1","1","oujar0k793lhk6e4rfjv5uqlj0","content","17","picture","9999999","","","","{SITE_URL}userfiles/media/content/cover_7.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("173","2014-11-13 12:16:05","2014-11-13 12:16:05","1","1","oujar0k793lhk6e4rfjv5uqlj0","content","16","picture","0","","","","{SITE_URL}userfiles/media/content/2014111312160510552010753_d67134c914_h.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("174","2014-11-13 12:17:44","2014-11-13 12:17:44","1","1","oujar0k793lhk6e4rfjv5uqlj0","content","12","picture","0","","","","{SITE_URL}userfiles/media/content/8939985436_6101fd18b7_o.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("176","2014-11-13 12:17:44","2014-11-13 12:17:44","1","1","oujar0k793lhk6e4rfjv5uqlj0","content","12","picture","2","","","","{SITE_URL}userfiles/media/content/2014111312174412729651625_1cac411099_bqwd.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("177","2014-11-13 12:17:44","2014-11-13 12:17:44","1","1","oujar0k793lhk6e4rfjv5uqlj0","content","12","picture","1","","","","{SITE_URL}userfiles/media/content/2014111312174413858750125_c2bf72642b_b.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("188","2014-11-13 13:18:24","2014-11-13 13:18:24","1","1","fv3rejhclkgopptd4ji601pmk0","content","9","picture","2","","","","{SITE_URL}userfiles/media/content/6028849961_c123999955_z.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("189","2014-11-13 15:58:19","2014-11-13 13:18:24","1","1","fv3rejhclkgopptd4ji601pmk0","content","9","picture","0","","","","{SITE_URL}userfiles/media/content/amateur_photography.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("190","2014-11-13 13:18:24","2014-11-13 13:18:24","1","1","fv3rejhclkgopptd4ji601pmk0","content","9","picture","1","","","","{SITE_URL}userfiles/media/content/aparat.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("192","2014-11-13 13:18:25","2014-11-13 13:18:25","1","1","fv3rejhclkgopptd4ji601pmk0","content","9","picture","4","","","","{SITE_URL}userfiles/media/content/photography_beginner.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("193","2014-11-13 13:22:18","2014-11-13 13:22:18","1","1","fv3rejhclkgopptd4ji601pmk0","content","9","picture","3","","","","{SITE_URL}userfiles/media/content/photography_business_management_tips_1_2_800x477.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("194","2014-11-13 13:56:54","2014-11-13 13:56:54","1","1","fv3rejhclkgopptd4ji601pmk0","content","8","picture","9999999","","","","{SITE_URL}userfiles/media/content/439158498_359.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("195","2014-11-13 13:56:54","2014-11-13 13:56:54","1","1","fv3rejhclkgopptd4ji601pmk0","content","8","picture","9999999","","","","{SITE_URL}userfiles/media/content/439158599_860.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("196","2014-11-13 14:00:25","2014-11-13 14:00:25","1","1","fv3rejhclkgopptd4ji601pmk0","content","6","picture","1","","","","{SITE_URL}userfiles/media/content/mountain_bag_large_camping_bag_1_.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("197","2014-11-13 14:00:26","2014-11-13 14:00:26","1","1","fv3rejhclkgopptd4ji601pmk0","content","6","picture","0","","","","{SITE_URL}userfiles/media/content/mountain_bag_large_camping_bag.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("198","2014-11-13 14:36:02","2014-11-13 14:36:02","1","1","fv3rejhclkgopptd4ji601pmk0","content","16","picture","3","","","","{SITE_URL}userfiles/media/content/9622657288_07af56dc29_c.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("199","2014-11-13 14:36:02","2014-11-13 14:36:02","1","1","fv3rejhclkgopptd4ji601pmk0","content","16","picture","2","","","","{SITE_URL}userfiles/media/content/9756849575_1cc190666e_b.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("201","2014-11-13 14:51:35","2014-11-13 14:51:35","1","1","fv3rejhclkgopptd4ji601pmk0","content","17","picture","9999999","","","","{SITE_URL}userfiles/media/content/2012_1037.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("212","2014-11-14 12:41:48","2014-11-14 12:41:48","1","1","u6bcngc5clonlh98ksad0fepm5","content","4","picture","0","","","","{SITE_URL}userfiles/media/content/du_211014_01_940x531.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("213","2014-11-14 12:41:48","2014-11-14 12:41:48","1","1","u6bcngc5clonlh98ksad0fepm5","content","4","picture","2","","","","{SITE_URL}userfiles/media/content/fo_280614_01_630x420.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("214","2014-11-14 12:41:48","2014-11-14 12:41:48","1","1","u6bcngc5clonlh98ksad0fepm5","content","4","picture","3","","","","{SITE_URL}userfiles/media/content/20141114124148ft_040614_01_630x529.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("215","2014-11-14 12:41:48","2014-11-14 12:41:48","1","1","u6bcngc5clonlh98ksad0fepm5","content","4","picture","4","","","","{SITE_URL}userfiles/media/content/gb_050314_03_630x471.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("216","2014-11-14 12:41:48","2014-11-14 12:41:48","1","1","u6bcngc5clonlh98ksad0fepm5","content","4","picture","5","","","","{SITE_URL}userfiles/media/content/gh_230414_01_630x460.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("217","2014-11-14 12:41:49","2014-11-14 12:41:49","1","1","u6bcngc5clonlh98ksad0fepm5","content","4","picture","6","","","","{SITE_URL}userfiles/media/content/gr_170814_01_630x645.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("218","2014-11-14 12:41:49","2014-11-14 12:41:49","1","1","u6bcngc5clonlh98ksad0fepm5","content","4","picture","7","","","","{SITE_URL}userfiles/media/content/hp_210313_02_630x639.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("219","2014-11-14 12:41:49","2014-11-14 12:41:49","1","1","u6bcngc5clonlh98ksad0fepm5","content","4","picture","8","","","","{SITE_URL}userfiles/media/content/mb_280713_07_630x420.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("220","2014-11-14 12:41:49","2014-11-14 12:41:49","1","1","u6bcngc5clonlh98ksad0fepm5","content","4","picture","9","","","","{SITE_URL}userfiles/media/content/mk_161212_09_630x310.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("221","2014-11-14 12:41:49","2014-11-14 12:41:49","1","1","u6bcngc5clonlh98ksad0fepm5","content","4","picture","1","","","","{SITE_URL}userfiles/media/content/mo_231014_03_940x626.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("222","2014-11-14 12:41:49","2014-11-14 12:41:49","1","1","u6bcngc5clonlh98ksad0fepm5","content","4","picture","10","","","","{SITE_URL}userfiles/media/content/po_140113_09_630x424.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("223","2014-11-14 12:41:49","2014-11-14 12:41:49","1","1","u6bcngc5clonlh98ksad0fepm5","content","4","picture","11","","","","{SITE_URL}userfiles/media/content/ro_010714_01_630x890.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("224","2014-11-14 12:41:49","2014-11-14 12:41:49","1","1","u6bcngc5clonlh98ksad0fepm5","content","4","picture","12","","","","{SITE_URL}userfiles/media/content/sl_161014_01_940x664.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("225","2014-11-14 12:41:50","2014-11-14 12:41:50","1","1","u6bcngc5clonlh98ksad0fepm5","content","4","picture","13","","","","{SITE_URL}userfiles/media/content/ss_090113_01_630x413.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("226","2014-11-14 12:41:50","2014-11-14 12:41:50","1","1","u6bcngc5clonlh98ksad0fepm5","content","4","picture","14","","","","{SITE_URL}userfiles/media/content/sw_270514_01_630x585.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("255","2014-11-14 13:41:34","2014-11-14 13:41:34","1","1","q9tuu1g9viojgag307h6scno00","content","13","picture","9999999","","","","{SITE_URL}userfiles/media/content/20141114134134Tulips.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("256","2014-11-24 12:06:41","2014-11-24 12:06:41","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","20","picture","1","","","","{SITE_URL}userfiles/media/test4-com/content/10295747216_35470c8cb7_k_min.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("257","2014-11-24 12:06:41","2014-11-24 12:06:41","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","20","picture","2","","","","{SITE_URL}userfiles/media/test4-com/content/12729651625_1cac411099_bqwd.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("258","2014-11-24 12:06:41","2014-11-24 12:06:41","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","20","picture","3","","","","{SITE_URL}userfiles/media/test4-com/content/13858750125_c2bf72642b_b.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("259","2014-11-24 12:06:41","2014-11-24 12:06:41","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","20","picture","4","","","","{SITE_URL}userfiles/media/test4-com/content/13982700002_f0e697fe2f_b.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("260","2014-11-24 12:06:42","2014-11-24 12:06:42","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","20","picture","5","","","","{SITE_URL}userfiles/media/test4-com/content/14473081211_663d96ef47_b.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("261","2014-11-24 12:15:25","2014-11-24 12:15:25","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","17","picture","9999999","","","","{SITE_URL}userfiles/media/test4-com/content/2012_1003.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("262","2014-11-24 12:18:13","2014-11-24 12:18:13","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","30","picture","1","","","","{SITE_URL}userfiles/media/test4-com/content/bs_020714_01_630x398.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("263","2014-11-24 12:18:13","2014-11-24 12:18:13","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","30","picture","2","","","","{SITE_URL}userfiles/media/test4-com/content/bt_230614_02_630x420.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("264","2014-11-24 12:18:13","2014-11-24 12:18:13","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","30","picture","3","","","","{SITE_URL}userfiles/media/test4-com/content/cb_020914_01_630x415.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("265","2014-11-24 12:18:13","2014-11-24 12:18:13","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","30","picture","0","","","","{SITE_URL}userfiles/media/test4-com/content/di_040914_01_630x453.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("266","2014-11-24 12:18:14","2014-11-24 12:18:14","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","30","picture","4","","","","{SITE_URL}userfiles/media/test4-com/content/ft_040614_01_630x529.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("267","2014-11-24 12:18:14","2014-11-24 12:18:14","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","30","picture","5","","","","{SITE_URL}userfiles/media/test4-com/content/in_270514_01_630x861.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("268","2014-11-24 12:30:54","2014-11-24 12:30:54","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","32","picture","2","","","","{SITE_URL}userfiles/media/test4-com/content/be_150714_03_630x470.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("269","2014-11-24 12:30:54","2014-11-24 12:30:54","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","32","picture","1","","","","{SITE_URL}userfiles/media/test4-com/content/bo_290514_01_630x420.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("270","2014-11-24 12:30:54","2014-11-24 12:30:54","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","32","picture","0","","","","{SITE_URL}userfiles/media/test4-com/content/bs_271113_01_630x353.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("271","2014-11-24 12:30:54","2014-11-24 12:30:54","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","32","picture","3","","","","{SITE_URL}userfiles/media/test4-com/content/ti_220814_01.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("272","2014-11-24 12:30:54","2014-11-24 12:30:54","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","32","picture","4","","","","{SITE_URL}userfiles/media/test4-com/content/to_041014_01_940x626.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("273","2014-11-24 12:32:21","2014-11-24 12:32:21","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","31","picture","1","","","","{SITE_URL}userfiles/media/test4-com/content/pr_120814_08_630x420.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("274","2014-11-24 12:32:21","2014-11-24 12:32:21","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","31","picture","2","","","","{SITE_URL}userfiles/media/test4-com/content/ro_010714_01_630x890.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("275","2014-11-24 12:32:21","2014-11-24 12:32:21","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","31","picture","0","","","","{SITE_URL}userfiles/media/test4-com/content/sw_270514_01_630x585.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("276","2014-11-24 12:32:21","2014-11-24 12:32:21","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","31","picture","3","","","","{SITE_URL}userfiles/media/test4-com/content/tc_061212_08_630x472.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("277","2014-11-24 12:32:21","2014-11-24 12:32:21","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","31","picture","4","","","","{SITE_URL}userfiles/media/test4-com/content/tw_071114_18_630x465.jpg"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */media VALUES("278","2014-11-24 12:32:22","2014-11-24 12:32:22","1","1","m4c9jgr1hf85s3fng3i366tpo2","content","31","picture","5","","","","{SITE_URL}userfiles/media/test4-com/content/wo_190614_01_630x548.jpg"); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS `/* MW_PREFIX_PLACEHOLDER */menus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` text,
  `item_type` varchar(33) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `content_id` int(11) DEFAULT NULL,
  `categories_id` int(11) DEFAULT NULL,
  `position` int(11) DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `is_active` char(1) DEFAULT 'y',
  `description` text,
  `url` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("1","header_menu","menu","0","0","0","0","2014-02-21 08:57:41","2014-02-21 08:57:41","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("2","footer_menu","menu","0","0","0","0","2014-02-21 08:59:01","2014-02-21 08:59:01","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("4","","menu_item","1","13","0","1","2014-02-28 08:48:56","2014-02-28 08:48:56","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("6","","menu_item","1","14","0","0","2014-03-17 11:20:53","2014-03-17 11:20:53","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("10","","menu_item","1","20","0","3","2014-03-24 10:48:09","2014-03-24 10:48:09","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("12","","menu_item","1","25","0","5","2014-03-26 17:03:37","2014-03-26 17:03:37","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("13","","menu_item","1","4","0","2","2014-03-27 11:40:23","2014-03-27 11:40:23","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("18","","menu_item","2","14","","99999","2014-03-31 14:14:48","2014-03-31 14:14:48","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("19","","menu_item","2","4","","99999","2014-03-31 14:14:52","2014-03-31 14:14:52","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("20","","menu_item","2","13","","99999","2014-03-31 14:14:55","2014-03-31 14:14:55","y","",""); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */menus VALUES("21","","menu_item","1","29","","4","2014-11-13 12:25:42","2014-11-13 12:25:42","y","",""); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS `/* MW_PREFIX_PLACEHOLDER */notifications` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `edited_by` int(11) DEFAULT NULL,
  `data_type` text,
  `title` longtext,
  `description` text,
  `content` text,
  `module` text,
  `rel` text,
  `rel_id` text,
  `notif_count` int(11) DEFAULT '1',
  `is_read` char(1) DEFAULT 'n',
  PRIMARY KEY (`id`),
  KEY `rel` (`rel`(55)),
  KEY `rel_id` (`rel_id`(55))
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */notifications VALUES("1","2014-11-14 09:57:46","2014-11-14 09:57:46","1","1","","New form entry","You have new form entry","You have new form entry from {SITE_URL}contacts&lt;br /&gt;&lt;ul&gt;&lt;li&gt;Captcha: as&lt;/li&gt;&lt;li&gt;Ip: 192.168.0.107&lt;/li&gt;&lt;/ul&gt;","contact_form","forms_lists","0","1","n"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */notifications VALUES("2","2014-11-14 11:21:55","2014-11-14 11:21:55","","","","New user registration","You have new user registration","You have new user registered with the username [test@test.com] and id [2]","users","users","2","1","n"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */notifications VALUES("3","2014-11-14 11:22:18","2014-11-14 11:22:18","","","","New user registration","You have new user registration","You have new user registered with the username [quantov@abv.bg] and id [3]","users","users","3","1","n"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */notifications VALUES("4","2014-11-14 11:26:36","2014-11-14 11:25:29","","1","","You have new order","New order is placed from {SITE_URL}checkout","New order in the online shop. Order id: 1","shop","cart_orders","1","1","y"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */notifications VALUES("5","2014-11-14 13:09:53","2014-11-14 12:05:18","1","1","","You have new order","New order is placed from {SITE_URL}checkout","New order in the online shop. Order id: 2","shop","cart_orders","2","1","y"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */notifications VALUES("6","2014-11-14 13:09:53","2014-11-14 12:07:49","1","1","","You have new order","New order is placed from {SITE_URL}checkout","New order in the online shop. Order id: 3","shop","cart_orders","3","1","y"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */notifications VALUES("7","2014-11-24 12:51:45","2014-11-24 12:51:45","","","","New form entry","You have new form entry","You have new form entry from {SITE_URL}contacts&lt;br /&gt;&lt;ul&gt;&lt;li&gt;Captcha: 3529&lt;/li&gt;&lt;li&gt;Ip: 192.168.0.107&lt;/li&gt;&lt;/ul&gt;","contact_form","forms_lists","0","1","n"); /* MW_QUERY_SEPERATOR */







CREATE TABLE IF NOT EXISTS `/* MW_PREFIX_PLACEHOLDER */options` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `updated_on` datetime DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `option_key` text,
  `option_value` longtext,
  `option_key2` text,
  `option_value2` longtext,
  `position` int(11) DEFAULT NULL,
  `option_group` text,
  `name` text,
  `help` text,
  `field_type` text,
  `field_values` text,
  `module` text,
  `is_system` int(1) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8; /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("1","2014-11-13 10:00:21","2014-11-13 10:00:21","website_title","Microweber","","","1","website","Website name","This is very important for search engines. Your website will be categorized by many criteria and its name is one of them.","text","","","1"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("2","2014-11-13 10:00:21","2014-11-13 10:00:21","website_description","My website description","","","2","website","Website description","Create Free Online Shop, Free Website and Free Blog with Microweber (MW)","textarea","","","1"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("3","2014-11-13 10:00:21","2014-11-13 10:00:21","website_keywords","free website, free shop, free blog, make web, mw, microweber","","","3","website","Website keywords","Write keywords for your site.","textarea","","","1"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("4","2014-11-13 10:01:09","2014-11-13 10:00:21","current_template","darock","","","5","template","Website template","This is your current template. You can easy change it anytime.","website_template","","","1"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("5","2014-11-13 10:00:21","2014-11-13 10:00:21","items_per_page","30","","","6","website","Items per page","Select how many items you want to have per page? example 10,25,50...","dropdown","YTo1OntpOjEwO3M6MjoiMTAiO2k6MzA7czoyOiIzMCI7aTo1MDtzOjI6IjUwIjtpOjEwMDtzOjM6IjEwMCI7aToyMDA7czozOiIyMDAiO30=","","1"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("6","2014-11-13 10:00:21","2014-11-13 10:00:21","enable_user_registration","y","","","10","users","Enable user registration","You can enable or disable the registration for new users","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","","1"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("7","2014-11-13 10:00:24","2014-11-13 10:00:24","currency","USD","","","1","payments","Currency","The website currency","currency","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("8","2014-11-13 10:00:24","2014-11-13 10:00:24","payment_currency","USD","","","2","payments","Payment currency","Payment process in currency","currency","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("9","2014-11-13 10:00:24","2014-11-13 10:00:24","payment_currency_rate","1.2","","","3","payments","Payment currency rate","Payment currency convert rate to site currency","currency","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("10","2014-11-13 10:00:28","2014-11-13 10:00:28","payment_currency","USD","","","2","payments","Payment currency","Payment process in currency","currency","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("11","2014-11-13 10:00:28","2014-11-13 10:00:28","payment_currency_rate","1.2","","","3","payments","Payment currency rate","Payment currency convert rate to site currency","currency","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("12","2014-11-13 10:00:41","2014-11-13 10:00:41","enable_automatic_backups","1 day","cronjob","","3","other","Enable automatic backups","You can enable or disable the automatic backups from here.","dropdown","YTo0OntzOjE6Im4iO3M6MjoiTm8iO3M6NToiMSBkYXkiO3M6NToiRGFpbHkiO3M6NjoiMSB3ZWVrIjtzOjY6IldlZWtseSI7czo3OiIxIG1vbnRoIjtzOjc6Ik1vbnRobHkiO30=","admin/backup","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("13","2014-11-13 10:00:41","2014-11-13 10:00:41","backups_to_keep","7","","","3","other","Backups to keep","Set the number of backups we should keep.","text","","admin/backup","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("14","2014-11-13 10:00:41","2014-11-13 10:00:41","backup_location","default","","","3","other","Backup location","Set where the backup files should be stored.","text","","admin/backup","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("15","2014-11-13 10:00:41","2014-11-13 10:00:41","backups_to_keep","7","","","3","other","Backups to keep","Set the number of backups we should keep.","text","","admin/backup","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("16","2014-11-13 10:00:41","2014-11-13 10:00:41","backup_location","default","","","3","other","Backup location","Set where the backup files should be stored.","text","","admin/backup","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("17","2014-11-13 10:00:41","2014-11-13 10:00:41","email_notifcation_on_comment","n","","","3","comments","Enable email notification on new comment","If yes it will send you email for every new comment","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","comments","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("18","2014-11-13 10:00:41","2014-11-13 10:00:41","enable_comments","y","","","5","comments","Allow people to post comments","If yes it will allow comments on your site","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","comments","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("19","2014-11-13 10:00:41","2014-11-13 10:00:41","enable_comments","y","","","5","comments","Allow people to post comments","If yes it will allow comments on your site","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","comments","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("20","2014-11-13 10:00:43","2014-11-13 10:00:43","thumbnail_size","original","","","3","other","Thumbnail Size","Example: 300x200 (width x height). Leave empty for original size","text","","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("21","2014-11-13 10:00:43","2014-11-13 10:00:43","image_link","y","","","3","other","Enable image link","If yes, the users will be able to click on the image","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("22","2014-11-13 10:00:43","2014-11-13 10:00:43","thumbnail_size","original","","","3","other","Thumbnail Size","Example: 300x200 (width x height). Leave empty for original size","text","","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("23","2014-11-13 10:00:43","2014-11-13 10:00:43","image_link","y","","","3","other","Enable image link","If yes, the users will be able to click on the image","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("24","2014-11-13 10:00:44","2014-11-13 10:00:44","enable_user_fb_login","n","","","3","other","Enable Facebook login","You can enable or disable login with facebook","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","users/register","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("25","2014-11-13 10:00:44","2014-11-13 10:00:44","enable_user_twitter_login","n","","","3","other","Enable Twitter login","You can enable or disable login with twitter","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","users/register","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("26","2014-11-13 10:00:44","2014-11-13 10:00:44","enable_user_email_confirmation","n","","","3","other","Email confirmation required","If set to yes, the user will need to confirm their email address","radio","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","users/register","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("27","2014-11-13 10:00:44","2014-11-13 10:00:44","enable_user_fb_login","n","","","3","other","Enable Facebook login","You can enable or disable login with facebook","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","users/register","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("28","2014-11-13 10:00:44","2014-11-13 10:00:44","enable_user_twitter_login","n","","","3","other","Enable Twitter login","You can enable or disable login with twitter","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","users/register","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("29","2014-11-13 10:00:44","2014-11-13 10:00:44","enable_user_email_confirmation","n","","","3","other","Email confirmation required","If set to yes, the user will need to confirm their email address","radio","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","users/register","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("30","2014-11-13 10:01:07","2014-11-13 10:01:07","backups_to_keep","7","","","3","other","Backups to keep","Set the number of backups we should keep.","text","","admin/backup","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("31","2014-11-13 10:01:07","2014-11-13 10:01:07","backup_location","default","","","3","other","Backup location","Set where the backup files should be stored.","text","","admin/backup","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("32","2014-11-13 10:01:07","2014-11-13 10:01:07","backups_to_keep","7","","","3","other","Backups to keep","Set the number of backups we should keep.","text","","admin/backup","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("33","2014-11-13 10:01:07","2014-11-13 10:01:07","backup_location","default","","","3","other","Backup location","Set where the backup files should be stored.","text","","admin/backup","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("34","2014-11-13 10:01:07","2014-11-13 10:01:07","enable_comments","y","","","5","comments","Allow people to post comments","If yes it will allow comments on your site","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","comments","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("35","2014-11-13 10:01:07","2014-11-13 10:01:07","enable_comments","y","","","5","comments","Allow people to post comments","If yes it will allow comments on your site","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","comments","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("36","2014-11-13 10:01:08","2014-11-13 10:01:08","thumbnail_size","original","","","3","other","Thumbnail Size","Example: 300x200 (width x height). Leave empty for original size","text","","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("37","2014-11-13 10:01:08","2014-11-13 10:01:08","image_link","y","","","3","other","Enable image link","If yes, the users will be able to click on the image","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("38","2014-11-13 10:01:08","2014-11-13 10:01:08","thumbnail_size","original","","","3","other","Thumbnail Size","Example: 300x200 (width x height). Leave empty for original size","text","","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("39","2014-11-13 10:01:08","2014-11-13 10:01:08","image_link","y","","","3","other","Enable image link","If yes, the users will be able to click on the image","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("40","2014-11-13 10:01:08","2014-11-13 10:01:08","enable_user_fb_login","n","","","3","other","Enable Facebook login","You can enable or disable login with facebook","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","users/register","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("41","2014-11-13 10:01:08","2014-11-13 10:01:08","enable_user_twitter_login","n","","","3","other","Enable Twitter login","You can enable or disable login with twitter","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","users/register","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("42","2014-11-13 10:01:08","2014-11-13 10:01:08","enable_user_email_confirmation","n","","","3","other","Email confirmation required","If set to yes, the user will need to confirm their email address","radio","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","users/register","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("43","2014-11-13 10:01:08","2014-11-13 10:01:08","enable_user_fb_login","n","","","3","other","Enable Facebook login","You can enable or disable login with facebook","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","users/register","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("44","2014-11-13 10:01:08","2014-11-13 10:01:08","enable_user_twitter_login","n","","","3","other","Enable Twitter login","You can enable or disable login with twitter","dropdown","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","users/register","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("45","2014-11-13 10:01:08","2014-11-13 10:01:08","enable_user_email_confirmation","n","","","3","other","Email confirmation required","If set to yes, the user will need to confirm their email address","radio","YToyOntzOjE6InkiO3M6MzoieWVzIjtzOjE6Im4iO3M6Mjoibm8iO30=","users/register","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("46","2014-11-13 10:57:16","2014-11-13 10:21:52","text","","","","","logo","","","","","logo","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("47","2014-11-17 15:11:11","2014-11-13 10:22:26","font_size","64","","","","logo","","","","","logo","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("48","2014-11-13 10:37:21","2014-11-13 10:23:17","logotype","both","","","","logo","","","","","logo","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("49","2014-11-13 10:39:28","2014-11-13 10:23:27","font_family","Dawning+of+a+New+Day","","","","logo","","","","","logo","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("50","2014-11-17 15:11:43","2014-11-13 10:35:53","logoimage","{SITE_URL}userfiles/media/test4-com/uploaded/logorock_4.png","","","","logo","","","","","logo","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("51","2014-11-17 15:38:31","2014-11-13 10:36:05","size","auto","","","","logo","","","","","logo","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("52","2014-11-13 11:39:08","2014-11-13 11:38:40","data-content-id","0","","","","--234309906","","","","","categories","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("53","2014-11-13 12:42:08","2014-11-13 12:21:03","data-template","simple.php","","","","-editor_tools-844116804","","","","","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("54","2014-11-13 13:35:10","2014-11-13 13:19:11","data-template","single.php","","","","-shop-20140228084856-14181533","","","","","shop/products","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("55","2014-11-13 14:36:45","2014-11-13 14:36:20","data-template","simple.php","","","","pictures-20140324112912","","","","","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("56","2014-11-13 14:56:13","2014-11-13 14:51:38","data-template","simple.php","","","","row_1395672540651","","","","","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("57","2014-11-13 16:09:47","2014-11-13 15:44:46","data-template","simple.php","","","","-editor_tools1167824773","","","","","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("58","2014-11-13 16:09:01","2014-11-13 15:53:45","data-template","simple.php","","","","-female-jeans1167824773","","","","","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("59","2014-11-13 16:10:00","2014-11-13 15:53:55","data-template","simple.php","","","","-bird-lamp1167824773","","","","","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("60","2014-11-24 12:35:01","2014-11-13 16:29:08","color-scheme","default","","","","mw-template-liteness","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("61","2014-11-17 12:01:06","2014-11-13 17:07:24","data-template","bootstrap_carousel.php","","","","-gallery2105103615","","","","","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("62","2014-11-14 09:57:02","2014-11-14 09:56:27","shipping_gw_shop/shipping/gateways/country","y","","","","shipping","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("63","2014-11-14 09:57:24","2014-11-14 09:57:24","paypalexpress_testmode","y","","","","payments","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("64","2014-11-14 09:57:26","2014-11-14 09:57:26","paypalpro_testmode","y","","","","payments","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("65","2014-11-14 09:57:28","2014-11-14 09:57:28","payment_gw_shop/payments/gateways/paypal","y","","","","payments","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("66","2014-11-14 09:57:29","2014-11-14 09:57:29","payment_gw_shop/payments/gateways/paypal_pro","y","","","","payments","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("67","2014-11-14 09:57:33","2014-11-14 09:57:33","pay_on_delivery_show_msg","y","","","","payments","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("68","2014-11-14 09:57:34","2014-11-14 09:57:34","payment_gw_shop/payments/gateways/pay_on_delivery","y","","","","payments","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("69","2014-11-14 10:05:15","2014-11-14 10:05:15","facebook_enabled","y","","","","-contacts-187965035","","","","","social_links","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("70","2014-11-14 10:05:16","2014-11-14 10:05:16","twitter_enabled","y","","","","-contacts-187965035","","","","","social_links","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("71","2014-11-14 10:05:16","2014-11-14 10:05:16","googleplus_enabled","y","","","","-contacts-187965035","","","","","social_links","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("72","2014-11-14 10:05:17","2014-11-14 10:05:17","pinterest_enabled","y","","","","-contacts-187965035","","","","","social_links","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("73","2014-11-14 10:05:18","2014-11-14 10:05:18","youtube_enabled","y","","","","-contacts-187965035","","","","","social_links","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("74","2014-11-14 10:05:28","2014-11-14 10:05:24","facebook_url","Microweber","","","","-contacts-187965035","","","","","social_links","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("75","2014-11-14 10:05:29","2014-11-14 10:05:29","twitter_url","microweber","","","","-contacts-187965035","","","","","social_links","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("76","2014-11-14 10:05:31","2014-11-14 10:05:31","googleplus_url","microweber","","","","-contacts-187965035","","","","","social_links","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("77","2014-11-14 10:05:35","2014-11-14 10:05:35","pinterest_url","microweber","","","","-contacts-187965035","","","","","social_links","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("78","2014-11-14 10:05:36","2014-11-14 10:05:36","youtube_url","microweber","","","","-contacts-187965035","","","","","social_links","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("79","2014-11-14 10:34:38","2014-11-14 10:34:38","enable_user_google_registration","y","","","","users","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("80","2014-11-14 10:34:39","2014-11-14 10:34:39","enable_user_github_registration","y","","","","users","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("81","2014-11-14 10:34:39","2014-11-14 10:34:39","enable_user_twitter_registration","y","","","","users","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("82","2014-11-14 10:34:40","2014-11-14 10:34:40","enable_user_windows_live_registration","y","","","","users","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("83","2014-11-14 11:28:38","2014-11-14 11:28:38","shop_require_terms","y","","","","website","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("84","2014-11-14 11:28:42","2014-11-14 11:28:42","shop_require_registration","y","","","","website","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("85","2014-11-14 12:16:56","2014-11-14 12:16:56","data-content-id","4","","","","-blog-1091108422","","","","","categories","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("86","2014-11-14 12:39:51","2014-11-14 12:39:51","data-template","simple.php","","","","-editor_tools-1462002108","","","","","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("87","2014-11-14 12:42:32","2014-11-14 12:42:29","data-template","simple.php","","","","-editor_tools1533426608","","","","","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("88","2014-11-14 12:50:37","2014-11-14 12:50:28","data-template","simple.php","","","","-cool-stuff1046843207","","","","","pictures","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("89","2014-11-14 12:51:35","2014-11-14 12:51:35","data-content-id","4","","","","-cool-stuff832622332","","","","","categories","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("90","2014-11-14 13:12:44","2014-11-14 13:12:40","email_transport","php","","","","email","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("91","2014-11-14 13:17:55","2014-11-14 13:17:55","data-template","single.php","","","","-shop-14181533","","","","","shop/products","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("92","2014-11-20 13:16:26","2014-11-20 13:11:22","font","font-robotoslab","","","","mw-template-liteness","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("93","2014-11-20 13:15:44","2014-11-20 13:11:37","custom_css_json","","","","","mw-template-liteness","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("94","2014-11-20 13:15:39","2014-11-20 13:12:55","bgimage","bgimage0","","","","mw-template-liteness","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("95","2014-11-20 13:14:59","2014-11-20 13:14:59","custom_bg","{SITE_URL}userfiles/media/test4-com/uploaded/imb1.jpg","","","","mw-template-liteness","","","","","","0"); /* MW_QUERY_SEPERATOR */


REPLACE INTO /* MW_PREFIX_PLACEHOLDER */options VALUES("96","2014-11-20 13:15:11","2014-11-20 13:15:11","custom_bg_position","right bottom","","","","mw-template-liteness","","","","","","0"); /* MW_QUERY_SEPERATOR */





